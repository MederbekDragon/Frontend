let Age = 21;
let year = 2000;
let name_ = 'Meder';

console.log(Age, year, name_);


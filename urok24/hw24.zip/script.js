var person = {
    name: "Mederbek",
    surname: "Bekboliev",
    age: 21,
    year_of_birth: 2000,
    place_of_birth: "Kyrgyzstan"
};

var meder = ['mederbek', 'bekboliev', 'hello', 'world', 2021];

console.log(meder[2]);

console.log(person.surname);
console.log(person.age);